	;; These are channel constants.
	SQUARE_1	= $00
	SQUARE_2	= $01
	TRIANGLE	= $02
	NOISE		= $03

	;; These are stream # constants. Stream # is used to index into variables.
	MUSIC_SQ1	= $00
	MUSIC_SQ2	= $01
	MUSIC_TRI	= $02
	MUSIC_NOI	= $03
	SFX_1		= $04
	SFX_2		= $05


; Local Variables: 
; mode: asm
; End: 
