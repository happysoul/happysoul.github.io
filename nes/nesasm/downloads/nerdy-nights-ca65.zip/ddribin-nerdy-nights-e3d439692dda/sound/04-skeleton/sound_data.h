
	.import	sfx1_data
	.import	sfx2_data
	.import	sfx3_data

; Local Variables: 
; mode: asm
; End: 
