
	.import		sound_init
	.import 	sound_disable
	.import		sound_load
	.import 	sound_play_frame

	.importzp 	sound_disable_flag
	.importzp	sfx_playing

; Local Variables: 
; mode: asm
; End: 
