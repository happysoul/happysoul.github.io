	
	;; If you add a new song, change this number.
	NUM_SONGS	= $07

	.global	song_headers
	
	
; Local Variables: 
; mode: asm
; End: 
