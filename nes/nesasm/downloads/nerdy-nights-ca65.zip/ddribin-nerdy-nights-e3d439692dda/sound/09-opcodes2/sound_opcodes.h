
	;; opcode constants
	endsound 	= $a0
	loop		= $a1
	volume_envelope	= $a2
	duty 		= $a3
	set_loop1_counter = $a4
	loop1		= $a5
	set_note_offset	= $a6
	adjust_note_offset = $a7
	transpose	= $a8

; Local Variables: 
; mode: asm
; End: 
