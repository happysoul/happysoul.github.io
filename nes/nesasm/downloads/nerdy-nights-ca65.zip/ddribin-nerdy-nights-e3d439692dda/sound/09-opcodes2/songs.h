	
	;; If you add a new song, change this number.
	NUM_SONGS	= $08

	.global	song_headers
	
	
; Local Variables: 
; mode: asm
; End: 
