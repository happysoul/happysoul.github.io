// a 16x16 pixel metasprite

const unsigned char PaddleSpr[]={
	  0,  0,0x00,0,
	  8,  0,0x00,0,
	  16,  0,0x00,0,
	  24,  0,0x00,0,
	128
};


const unsigned char BallSpr[]={
	  0,  0,0x01,0,
	128
};




