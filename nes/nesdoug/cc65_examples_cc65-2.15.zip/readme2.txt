note from dougeff

works with cc65 version 2.15

changed .cfg file (32k instead of 16k), linker symbols
changed the compile .bat files
changed the pragmas on example11
using nes.lib instead of runtime.lib

