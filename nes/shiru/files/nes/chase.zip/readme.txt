This is an example game that is developed for my article Programming NES games in C. The article itself is located at my website in the Articles section, to make things simpler in case of possible updates.

http://shiru.untergrund.net
mailto:shiru@mail.ru